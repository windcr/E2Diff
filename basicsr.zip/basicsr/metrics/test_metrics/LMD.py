import dlib
import cv2
import numpy as np
import os

# 初始化dlib的人脸检测器和关键点预测器
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("/mnt/data/wy_projects/DifFace-master/basicsr/metrics/test_metrics/shape_predictor_68_face_landmarks.dat")


def get_landmarks(image):
    """提取单张图片的人脸关键点"""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = detector(gray)
    for face in faces:
        landmarks = predictor(gray, face)
        return [(p.x, p.y) for p in landmarks.parts()]
    return None


def compute_lmd(landmarks1, landmarks2):
    """计算两组关键点之间的LMD值"""
    if landmarks1 is None or landmarks2 is None:
        return None
    distances = [np.linalg.norm(np.array(p1) - np.array(p2)) for p1, p2 in zip(landmarks1, landmarks2)]
    return np.mean(distances)


def calculate_dataset_lmd(original_dir, restored_dir):
    """计算整个数据集的LMD值"""
    total_lmd = 0
    count = 0
    for filename in os.listdir(original_dir):
        original_image_path = os.path.join(original_dir, filename)
        restored_image_path = os.path.join(restored_dir, filename)

        # 加载图片
        original_image = cv2.imread(original_image_path)
        restored_image = cv2.imread(restored_image_path)

        # 获取两张图片的关键点
        original_landmarks = get_landmarks(original_image)
        restored_landmarks = get_landmarks(restored_image)

        # 计算每对图片的LMD值
        lmd_value = compute_lmd(original_landmarks, restored_landmarks)

        if lmd_value is not None:
            total_lmd += lmd_value
            count += 1

    # 返回平均LMD值
    return total_lmd / count if count > 0 else None


# 示例：给定原始数据集和恢复数据集的路径
original_dataset_dir = "/mnt/data/wy_projects/datasets/CelebA_Test/hq"
restored_dataset_dir = "/mnt/data/wy_projects/DifFace-master/extend_expe/result/celeba_test_swinir_gfpgan/restored_faces"

# 计算整个数据集的LMD值
average_lmd = calculate_dataset_lmd(original_dataset_dir, restored_dataset_dir)
print("整个数据集的平均LMD值:", average_lmd)

