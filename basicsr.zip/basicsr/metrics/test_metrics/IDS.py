import torch
import numpy as np
import torchvision.transforms as transforms
from PIL import Image
import os
from facenet_pytorch import InceptionResnetV1

# 定义余弦相似度函数
def cosine_similarity(embedding1, embedding2):
    cos_sim = np.dot(embedding1, embedding2) / (np.linalg.norm(embedding1) * np.linalg.norm(embedding2))
    return cos_sim

# 计算IDS值 (夹角)
def calculate_ids(embedding1, embedding2):
    cos_sim = cosine_similarity(embedding1, embedding2)
    # 夹角的计算是反余弦函数
    angle = np.arccos(np.clip(cos_sim, -1.0, 1.0))  # 防止浮点误差
    return np.degrees(angle)  # 转换为角度

# 预处理图像函数
def preprocess_image(image_path):
    transform = transforms.Compose([
        transforms.Resize((160, 160)),  # Facenet需要的输入大小
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    ])
    img = Image.open(image_path).convert('RGB')
    img = transform(img).unsqueeze(0)  # 增加批量维度
    return img

# 加载预训练的 FaceNet 模型
def load_model():
    model = InceptionResnetV1(pretrained='vggface2').eval()  # 使用 VGGFace2 预训练模型
    return model

def get_embedding(model, img_tensor):
    with torch.no_grad():
        embedding = model(img_tensor)
    return embedding.squeeze().numpy()  # 将嵌入向量从 PyTorch tensor 转换为 numpy 数组

# 计算两个数据集的IDS
def calculate_dataset_ids(dataset_path1, dataset_path2):
    model = load_model()

    # 获取两个数据集中的所有图像路径
    images1 = [os.path.join(dataset_path1, f) for f in os.listdir(dataset_path1) if f.endswith(('jpg', 'png'))]
    images2 = [os.path.join(dataset_path2, f) for f in os.listdir(dataset_path2) if f.endswith(('jpg', 'png'))]

    ids_values = []

    # 遍历两个数据集的所有图像，并计算每对图像之间的IDS值
    for img_path1, img_path2 in zip(images1, images2):
        img1 = preprocess_image(img_path1)
        img2 = preprocess_image(img_path2)

        embedding1 = get_embedding(model, img1)
        embedding2 = get_embedding(model, img2)

        if embedding1 is not None and embedding2 is not None:
            ids_value = calculate_ids(embedding1, embedding2)
            ids_values.append(ids_value)

            print(f"IDS between {os.path.basename(img_path1)} and {os.path.basename(img_path2)}: {ids_value:.2f} degrees")
        else:
            print(f"Face not detected in one of the images: {os.path.basename(img_path1)} or {os.path.basename(img_path2)}")

    # 计算整体平均 IDS
    if ids_values:
        avg_ids = np.mean(ids_values)
        print(f"Average IDS between the two datasets: {avg_ids:.2f} degrees")
    else:
        print("No valid IDS values calculated.")

# 主函数
dataset1 = '/mnt/data/wy_projects/datasets/CelebA_Test/hq'  # 数据集1的路径
dataset2 = '/mnt/data/wy_projects/CodeFormer-master/results/celeba_test/restored_faces'  # 数据集2的路径
calculate_dataset_ids(dataset1, dataset2)
