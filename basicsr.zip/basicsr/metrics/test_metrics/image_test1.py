import os
import cv2
import torch

from basicsr.metrics import calculate_psnr, calculate_ssim
from basicsr.metrics.psnr_ssim import calculate_psnr_pt, calculate_ssim_pt
from basicsr.utils import img2tensor


# 设置高质量和低质量图像文件夹的路径
high_quality_dir = '/mnt/data/wy_projects/face-identity-transformer-master/qualitative_results/CelebA-HQ/checkpoints/checkpoint_13_iter8193/img'
low_quality_dir = '/mnt/data/wy_projects/GFPGAN-master/results/FIT/CelebA_HQ/recon/restored_imgs'

# 获取文件夹中的图像文件列表
high_quality_images = os.listdir(high_quality_dir)
low_quality_images = os.listdir(low_quality_dir)

# 初始化变量来存储PSNR和SSIM的累积值
psnr_sum = 0
ssim_sum = 0

# Define a function to compute PSNR
def calculate_psnr_(image1, image2, crop_border, test_y_channel):

    # # --------------------- Numpy ---------------------
    # psnr = calculate_psnr(image1, image2, crop_border=crop_border, input_order='HWC', test_y_channel=test_y_channel)

    # # --------------------- PyTorch (CPU) ---------------------
    # image1 = img2tensor(image1 / 255., bgr2rgb=True, float32=True).unsqueeze_(0)
    # image2 = img2tensor(image2 / 255., bgr2rgb=True, float32=True).unsqueeze_(0)
    # psnr = calculate_psnr_pt(image1, image2, crop_border=crop_border, test_y_channel=test_y_channel)
    # psnr = psnr.item()

    # --------------------- PyTorch (GPU) ---------------------
    image1 = img2tensor(image1 / 255., bgr2rgb=True, float32=True).unsqueeze_(0)
    image2 = img2tensor(image2 / 255., bgr2rgb=True, float32=True).unsqueeze_(0)
    image1 = image1.cuda()
    image2 = image2.cuda()
    psnr = calculate_psnr_pt(image1, image2, crop_border=crop_border, test_y_channel=test_y_channel)
    psnr = psnr.item()

    return psnr

# Define a function to compute SSIM
def calculate_ssim_(image1, image2, crop_border, test_y_channel):

    # # --------------------- Numpy ---------------------
    # ssim = calculate_ssim(image1, image2, crop_border=crop_border, input_order='HWC', test_y_channel=test_y_channel)

    # # --------------------- PyTorch (CPU) ---------------------
    # image1 = img2tensor(image1 / 255., bgr2rgb=True, float32=True).unsqueeze_(0)
    # image2 = img2tensor(image2 / 255., bgr2rgb=True, float32=True).unsqueeze_(0)
    # ssim = calculate_ssim_pt(image1, image2, crop_border=crop_border, test_y_channel=test_y_channel)
    # ssim = ssim.item()

    # --------------------- PyTorch (GPU) ---------------------
    image1 = img2tensor(image1 / 255., bgr2rgb=True, float32=True).unsqueeze_(0)
    image2 = img2tensor(image2 / 255., bgr2rgb=True, float32=True).unsqueeze_(0)
    image1 = image1.cuda()
    image2 = image2.cuda()
    ssim = calculate_ssim_pt(image1, image2, crop_border=crop_border, test_y_channel=test_y_channel)
    ssim = ssim.item()

    return ssim

# 循环遍历每对高质量和低质量图像并计算PSNR和SSIM
for i in range(len(high_quality_images)):
    high_img = cv2.imread(os.path.join(high_quality_dir, high_quality_images[i]))
    low_img = cv2.imread(os.path.join(low_quality_dir, low_quality_images[i]))

    # 确保两个图像具有相同的大小
    high_img = cv2.resize(high_img, (low_img.shape[1], low_img.shape[0]))

    # 计算PSNR
    psnr = calculate_psnr_(high_img, low_img, 0, True)
    print("psnr:", psnr)
    psnr_sum += psnr

    # 计算SSIM
    ssim_value = calculate_ssim_(high_img, low_img, 0, True)
    print("ssim:", ssim_value)
    ssim_sum += ssim_value

# 计算平均PSNR和平均SSIM
average_psnr = psnr_sum / len(high_quality_images)
average_ssim = ssim_sum / len(high_quality_images)

# 打印结果
print(f'平均PSNR: {average_psnr:.2f}')
print(f'平均SSIM: {average_ssim:.4f}')