Put the following models in this folder.
---arcface_model.pth
---shape_predictor_68_face_landmarks.dat